import { ApiSearchResult }      from '@mealspotter/common/interfaces/common';
import { IDealUrlContext }      from '@mealspotter/common/interfaces/urlContexts';
import { logService }           from '@mealspotter/frontend-common/services/LogService';
import { default as NextError } from 'next/error';
import * as React               from 'react';
import { DealDetailCard }       from '../../components/deal/DealDetailCard';
import { customerDealFacade }   from '../../facade/CustomerDealFacade';
import { geoLocationService }   from '../../services/GeoLocationService';

type Props = {
  query: IDealUrlContext;
  result: ApiSearchResult | undefined;
};

type State = { distance: number };

class DealDetails extends React.Component<Props, State> {
  public state = { distance: 0 };

  public static async getInitialProps(props: Props): Promise<Props> {
    try {
      const response = await customerDealFacade.getById({ url: props.query });

      if (response !== undefined) {
        const result: ApiSearchResult = {
          distance: 0,
          deals:    [response.deal],
          company:  response.company,
        };

        return { result, query: props.query };
      }

      logService.error(`Could not find deal ${props.query.dealId} of company "${props.query.companyId}"`);
    } catch (error) {
      logService.error(
        `Could not obtain details for deal ${props.query.dealId} of company "${props.query.companyId}"`,
        error,
      );
    }

    return { result: undefined, query: props.query };
  }

  public async componentWillMount(): Promise<void> {
    if (!this.props.result) {
      return;
    }

    // cannot throw
    const distance = await geoLocationService.getDifferenceToCurrentPoint(this.props.result.company.location);
    this.setState({ distance: Math.round(distance * 100) / 100 });
  }

  public render(): React.ReactNode {
    const { result, query } = this.props;

    if (!result) {
      return <NextError statusCode={404}/>;
    }

    const { distance } = this.state;
    const { deals, company } = result;

    const deal = deals.find(x => x.id === query.dealId);

    if (!deal) {
      return <NextError statusCode={404}/>;
    }

    return <DealDetailCard deal={deal} company={company} distance={distance}/>;

  }
}

export default DealDetails;
