import { observer }                 from 'mobx-react';
import Router                       from 'next/router';
import * as React                   from 'react';
import { CUSTOMER_COMPANY_ROUTES } from '../../../../common/routes/FrontendRoutes';
import { withMobxStore }            from '../../common/withMobxStore';
import { ViewWrapper }              from '../../components/common/ViewWrapper';
import { DealListView }             from '../../components/list/DealListView';
import { filterStore }              from '../../store/FilterStore';
import { searchStore }              from '../../store/SearchStore';

@observer
class DealListPage extends React.Component {
  public componentDidUpdate(): void {
    this.checkEmpty();
  }

  public componentDidMount(): void {
    this.checkEmpty();
  }

  public render(): React.ReactNode {
    return (
      <ViewWrapper>
        <DealListView searchStore={searchStore}/>
      </ViewWrapper>
    );
  }

  private checkEmpty(): void {
    const noDealsFound = filterStore.hasLoadedOnce && searchStore.currentDealResults.length === 0;

    if (noDealsFound) {
      return void Router.push(CUSTOMER_COMPANY_ROUTES.companyMapViewPath);
    }
  }
}

export default withMobxStore(DealListPage);
