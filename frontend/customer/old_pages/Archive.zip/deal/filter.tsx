import * as React        from 'react';
import { withMobxStore } from '../../common/withMobxStore';
import { FilterView }    from '../../components/filter/FilterView';

const _FilterPage = () => (
  <FilterView/>
);

export default (_FilterPage);
