// eslint-disable-next-line @typescript-eslint/no-unused-vars
import * as React     from 'react';
import MarketDetails from './details';

export default MarketDetails;
