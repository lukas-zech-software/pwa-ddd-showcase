import { Grid }                  from '@material-ui/core';
import { IApiMarket }            from '@mealspotter/common/interfaces/IApiMarket';
import { IMarketUrlContext }     from '@mealspotter/common/interfaces/urlContexts';
import { Loading }               from '@mealspotter/frontend-common/components';
import { logService }            from '@mealspotter/frontend-common/services/LogService';
import NextError                 from 'next/error';
import * as React                from 'react';
import { IApiCompany }           from '../../../../common/interfaces';
import { MarketDetailsCardList } from '../../components/market/MarketDetailsCardList';
import { MarketDetailViewCard }  from '../../components/market/MarketDetailViewCard';
import { MarketMetaData }        from '../../components/market/MarketMetaData';
import { customerCompanyFacade } from '../../facade/CustomerCompanyFacade';
import { customerMarketFacade }  from '../../facade/CustomerMarketFacade';
import { geoLocationService }    from '../../services/GeoLocationService';

type Props = {
  query: IMarketUrlContext;
  result: IApiMarket | undefined;
};

type State = {
  distance: number;
  companies: IApiCompany[]
};

class MarketDetails extends React.Component<Props, State> {
  public state = {
    distance:  0,
    companies: [],
  };

  public static async getInitialProps(props: Props): Promise<Props> {
    try {
      const response = await customerMarketFacade.getForId({ url: { marketId: props.query.marketId } });

      if (response) {
        return {
          result: response,
          query:  props.query,
        };
      }

      logService.error(`Could find market with id "${props.query.marketId}"`);
    } catch (error) {
      logService.error(`Could not obtain market with id "${props.query.marketId}"`, error);
    }

    return {
      result: undefined,
      query:  props.query,
    };
  }

  public async componentWillMount(): Promise<void> {
    if (!this.props.result) {
      return;
    }

    // cannot throw
    const distance = await geoLocationService.getDifferenceToCurrentPoint(this.props.result.location);

    this.setState({ distance: Math.round(distance * 100) / 100 });

    const companyIds = this.props.result.companyIds;
    const companies  = await Promise.all(companyIds.map((companyId) => customerCompanyFacade.getForId({ url: { companyId } })));
    const filtered   = companies.filter(x => !!x) as IApiCompany[];
    this.setState({ companies: filtered });
  }

  public render(): React.ReactNode {
    const { result }    = this.props;
    const { companies } = this.state;

    if (result === undefined) {
      return <NextError statusCode={404}/>;
    }

    return (
      <>
        <MarketMetaData market={result}/>
        <Grid container>
          <Grid item xs={12}>
            <MarketDetailViewCard market={result} distance={this.state.distance}/>
          </Grid>
          <Grid item xs={12}>
            {companies.length !== 0 ? <MarketDetailsCardList companies={companies}/> : <Loading/>}
          </Grid>
        </Grid>
      </>
    );
  }
}

export default MarketDetails;
